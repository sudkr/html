class Login {
    constructor(StudentId, StudentName, StudentYear, StudentDepartment) {
        this.StudentId = StudentId;
        this.StudentName = StudentName;
        this.StudentYear = StudentYear;
        this.StudentDepartment = StudentDepartment;
    }

    printAllData() {
        let StudentDetails =
            `
        Student ID: ${this.StudentId}
        Student Name: ${this.StudentName}
        Student Year: ${this.StudentYear}
        Student Department: ${this.StudentDepartment}
        `;
        return StudentDetails;
    }

    logIn() {
        console.log("Student Added..(Super Method)");
    }

    logOut() {
        console.log("Student Deleted..(Super Method)");
    }
}

class Student extends Login {
    constructor(StudentId, StudentName, StudentYear, StudentDepartment) {
        super(StudentId, StudentName, StudentYear, StudentDepartment);
    }

    printAllData() {
        let StudentDetails = super.printAllData();
        return StudentDetails;
    }

    logIn() {
        super.logIn();
    }

    logOut() {
        super.logOut();
    }
}

var StudentObj1 = new Student(1002, "Shray", 2, "ECE");
var StudentObj2 = new Student(1003, "Ankit", 1, "IT");
var StudentObj3 = new Student(1001, "Rishabh", 3, "CSE");
var StudentObj4 = new Student(1000, "Jitesh", 4, "EEE");

let allStudents = [];
allStudents.push(StudentObj1);
StudentObj1.logIn();
allStudents.push(StudentObj2);
StudentObj2.logIn();
allStudents.push(StudentObj3);
StudentObj3.logIn();
allStudents.push(StudentObj4);
StudentObj4.logIn();

let sortedArray = allStudents.sort((a, b) => a.StudentId - b.StudentId);

console.log("Displaying All Students List in Ascending Order:");
for (let Students in allStudents) {
    console.log(allStudents[Students].printAllData());
}

let updateStudentId = prompt("Enter Student ID to Update:");
var flagUpdate = false;
for (let Students in allStudents) {
    if (allStudents[Students].StudentId == updateStudentId) {
        allStudents[Students].StudentName = "Updated";
        console.log("Student Updated.. Displaying Updated List..");
        flagUpdate = true;
        for (let Students in allStudents) {
            console.log(allStudents[Students].printAllData());
        }
    }
}
if (!flagUpdate) {
    console.log("Student ID does not exist, not updated..");
    for (let Students in allStudents) {
        console.log(allStudents[Students].printAllData());
    }

}

let deleteStudentId = prompt("Enter Student ID to Delete:");
var flagDelete = false;
for (let Students in allStudents) {
    if (allStudents[Students].StudentId == deleteStudentId) {
        allStudents.splice(Students, 1);
        StudentObj1.logOut();
        flagDelete = true;
        for (let Students in allStudents) {
            console.log(allStudents[Students].printAllData());
        }
    }
}
if (!flagDelete) {
    console.log("Student ID does not exist, not deleted..");
    for (let Students in allStudents) {
        console.log(allStudents[Students].printAllData());
    }

}