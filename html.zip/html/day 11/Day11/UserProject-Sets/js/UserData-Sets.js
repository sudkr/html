class Inventory {
    //Super Method
    getUserIn() {
        console.log("User In..(Super Method)");
    }

    //Super Method
    getUserOut() {
        console.log("User Out..(Super Method)");
    }
}

class User extends Inventory {
    //Constructor
    constructor(uId, uName, uAge, uCity) {
        super();
        this.uId = uId;
        this.uName = uName;
        this.uAge = uAge;
        this.uCity = uCity;
    }

    //Method to Show User Data
    printAllData() {
        let userDetails =
            `
        User ID: ${this.uId}
        User Name: ${this.uName}
        User Age: ${this.uAge}
        User City: ${this.uCity}
        `;

        return userDetails;
    }

    getUserIn() {
        super.getUserIn();
    }

    getUserOut() {
        super.getUserOut();
    }
}


//Creating Objects of User Class
var userObj1 = new User(1002, "Rahul", 19, "Mumbai");
var userObj2 = new User(1003, "Ram", 66, "Pune");
var userObj3 = new User(1001, "Penny", 32, "Delhi");
var userObj4 = new User(1000, "Sheldon", 30, "Delhi");

//Creating Set of User Data
let allUsers = new Set();
allUsers.add(userObj1);
userObj1.getUserIn();
allUsers.add(userObj2);
userObj2.getUserIn();
allUsers.add(userObj3);
userObj3.getUserIn();
allUsers.add(userObj4);
userObj4.getUserIn();

console.log("Displaying All Users Set Data..");
for (let users of allUsers) {
    console.log(users.printAllData());
}

//Sorting Data
let sortedSet = Array.from(allUsers).sort((a, b) => a.uAge - b.uAge);
console.log("Displaying Sorted User Set Data..");
for (let users of sortedSet) {
    console.log(users.printAllData());
}

//Accepting Data from User
let updateUserId = prompt("Enter UserID to Update:");
let updateUserIdResult = Array.from(allUsers).find(k => k.uId == updateUserId);
if (updateUserIdResult == undefined) {
    console.log("User Not Found.. Not Updated..");
}
else {
    updateUserIdResult.uName = "Updated_Name";
    console.log("Displaying Updated User Data:");
    for (let users of allUsers) {
        console.log(users.printAllData());
    }
}

//Accepting Data from User
let deleteUserId = prompt("Enter UserID to Delete:");
let deleteUserIdResult = Array.from(allUsers).find(k => k.uId == deleteUserId);
if (deleteUserIdResult == undefined) {
    console.log("User Not Found.. Not Deleted..");
}
else {
    allUsers.delete(deleteUserIdResult);
    userObj1.getUserOut() + " " + console.log(deleteUserId);
    console.log("Displaying Deleted Set:");
    for (let users of allUsers) {
        console.log(users.printAllData());
    }
}