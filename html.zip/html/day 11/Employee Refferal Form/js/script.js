function doRefferal(frmRefferal) {

    //This method will check the form validation

    if (frmRefferal.checkValidity()) {

        var FirstName = frmRefferal.txtFirstName.value;
        var LastName = frmRefferal.txtLastName.value;
        var Mobile = frmRefferal.txtMobile.value;
        var Email = frmRefferal.txtEmail.value;
        var dateOfBirth = frmRefferal.dateOfBirth.value;
        var ddlCity = frmRefferal.ddlCity.value;
        var sessionKey='SessionActive';

        //Session Storage is used for storing the temporary data

        sessionStorage.setItem("FirstName", FirstName);
        sessionStorage.setItem("LastName", LastName);
        sessionStorage.setItem("Mobile", Mobile);
        sessionStorage.setItem("Email", Email);
        sessionStorage.setItem("dateOfBirth", dateOfBirth);
        sessionStorage.setItem("ddlCity", ddlCity);
        sessionStorage.setItem("sessionKey", sessionKey);

    }
}

function successRefferal() {

    var txtState;

    //Session Storage is used for getting the temporary stored data

    document.getElementById("txtFirstName").innerHTML = sessionStorage.getItem("FirstName");
    document.getElementById("txtLastName").innerHTML = sessionStorage.getItem("LastName");
    document.getElementById("txtMobile").innerHTML = sessionStorage.getItem("Mobile");
    document.getElementById("txtEmail").innerHTML = sessionStorage.getItem("Email");
    document.getElementById("dateOfBirth").innerHTML = sessionStorage.getItem("dateOfBirth");
    document.getElementById("ddlCity").innerHTML = sessionStorage.getItem("ddlCity");

    if (sessionStorage.getItem("ddlCity") == 'Pune' || sessionStorage.getItem("ddlCity") == 'Mumbai') {
        txtState = 'Maharastra';
    }
    else if (sessionStorage.getItem("ddlCity") == 'Chennai') {
        txtState = 'Tamil Nadu';
    }
    else {
        txtState = 'Karnataka';
    }

    document.getElementById("txtState").innerHTML = txtState;
}

function isAuthorized(){
    
    if(sessionStorage.getItem("sessionKey")==null){
        window.location.href="EmployeeRefferalForm.html";
    }
    else{
        successRefferal();
    }
}