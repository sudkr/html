// for loop
function findFactorial_ForLoop(num){
    // isFinite() function checks for numeric value//
    if(num.value == "" || isFinite(num.value)==false)
    alert("Please enter Only Numeric Value ..!")

    else
    {
        var n = parseInt(num.value);
        var fact=1;
        //1-Intialization; 2-Test Cond;
        for(var i=1; i<=n; i++)
        fact *=i;
        alert("Factorial of "+n+" is "+fact);
    }
}

// for whileLoop
function findFactorial_WhileLoop(num){
    // isFinite() finction checks for numeric value//
    if(num.value=="" || isFinite(num.value)==false)
    alert("Please enter Only Numeric Value ..!")

    else
    {
        var n = parseInt(num.value);
        var fact=1;
        //1-Intialization; 
        var i=1;
        //2-Test Cond;
        while(i<=n){
        fact *=i;  //3-body of the loop
        i++        //4-Incre/Decre
        }
        alert("Factorial of "+n+" is "+fact);
    }
}
/* Function with variable number of Arguments */
function function_Arguments(separator){
   // alert('1')
    var result="";
    for(var i=1; i<arguments.length;i++)
    result += arguments[i]+separator;
    document.write("<h2>"+result+"</h2>");
}
/* Sum of n numbers */
function addition(){
var sum=0;
for(var i=0; i<arguments.length;i++)
sum+=parseInt(arguments[i]);
return sum;
}
document.write("<h3>addition(10,20,30):"
    +addition(10,20,30)+"<h3>");
    document.write("<h3>addition(10,20):"
    +addition(10,20,)+"<h3>");
    document.write("<h3>addition():"
    +addition()+"<h3>");
    document.write("<h3>addition(10,20,30,40,50):"
    +addition(10,20,30,40,50)+"<h3>");


