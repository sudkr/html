// Declaring and initializing an array in one line
var listofBoys = ["Pawan","Kishore","Sai"];
var listofGirls = new Array("Ritu","Shalini","Niharika");

//Empty declartion
// var numbers =[];
// var courses = new Array();

document.write("<h3>"+listofBoys+"</h3>");
document.write("<h3>"+listofGirls+"</h3>");

document.write("<h3>Displaying Boys using loops</h3>");
document.write("<h4>Boys count:"+listofBoys.length+"</h3>");
for(var i=0; i<listofBoys.length;i++);
document.write(listofBoys[i]+"<br/>");

listofBoys.push("Mukund");
document.write("<h3>Displaying Boys after adding Mukund</h3>");
document.write("<h3>"+listofBoys+"</h3>");
document.write("<h4>Boys count:"+listofBoys.length+"</h4>");

document.write("<h4>Girls count:"+listofGirls.length+"</h4>");
document.write("<h3>Displaying Girls using loops</h3>");
for(var i=0; i<listofGirls.length;i++)
document.write(listofGirls[i].bold().italics()+"<br/>");

listofBoys.unshift("Shreya");
document.write("<h3>Displaying Girls after adding Shreya</h3>");
document.write("<h3>"+listofGirls+"</h3>");
document.write("<h4>Boys count:"+listofGirls.length+"</h4>");

//pop() is used to remove element from end
// and returns deleted element
listofGirls.pop();
document.write("<h3>"+listofGirls+"</h3>");
document.write("<h4>Boys count:"+listofGirls.length+"</h4>");

// adding element in between or at specific location

document.write("<h3>Sort Girls in AscendingOrder</h3>");
listofGirls.sort();
for(var i=0; i<listofGirls.length;i++)
document.write(listofGirls[i].bold().italics()+"<br/>");

document.write("<h3>Sort Girls in DescendingOrder</h3>");
listofGirls.reverse();
for(var i=0; i<listofGirls.length;i++)
document.write(listofGirls[i].bold().italics()+"<br/>");

var listOfParticipants = listofGirls.concat(listofBoys);
document.write("<h3>Final List in Ascending Order</h3>");
listOfParticipants.sort();
for(var i=0; i<listOfParticipants.length;i++)
document.write(listOfParticipants[i].bold().italics()+"<br/>");

var finalList = listOfParticipants.join(',');
document.write("<h3>Final List:"+finalList+"</h3>");
//slice will return selected list of elements
document.write("<h3>First 3:"+ listOfParticipants.slice(0,3)+"</h3>");

//spice will return selected list of elements
//an array  with deleting it
// even you can add elemnet even in at specific location
// second parameter is optional, and if you mention 0 means no deletion
// first parameter is start
// second is delectioncount
// third parameter is string array or you can pass indivisual items
listOfParticipants.splice(0,2, "Amiksha","Samiksha");
document.write("<h1>"+listOfParticipants+"<h1>");
