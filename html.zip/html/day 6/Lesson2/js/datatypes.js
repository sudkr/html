var anyType;

document.write("Type: "+typeof(anyType)+" "+"Value:"+anyType);
//string type
anyType="Sud";
document.write("<br/>Type:"+typeof(anyType)+" "+"Value:"+anyType);
//number type
anyType=10000;
document.write("<br/>Type:"+typeof(anyType)+" "+"Value:"+anyType);
//boolean type
anyType=false;
document.write("<br/>Type:"+typeof(anyType)+" "+"Value:"+anyType);
//obj type
 anyType=null;
document.write("<br/>Type:"+typeof(anyType)+" "+"Value:"+anyType);