function calculateACircle(){
   calculate();
}
function calculate(){
    var radius=parseFloat(prompt("Enter radius:"));

    var area = Math.PI * radius * radius;

    alert("Area of circle is "+area);

    var result =  confirm("Do you want continue ?");
    if(result == true)
    {
        calculate();
    }
}

var IntervalObj;
function setIntervalFunc() {
    alert('u have  Started Interval..!')
    IntervalObj = setInterval(function(){
        alert('Hello World');
    }, 2000);
}
function clearIntervalFunc(){
    clearInterval(IntervalObj);
    alert('U have stopped interval..!');

}
// setTimeOut() and clearTimeout()
var timeOutObj;
function setTimeOutFunc() {
    alert('u have  Started timeOut..!');
    timeOutObj = setTimeout(function(){
        alert('Hello World');
    }, 3000);
}
function clearTimeOutFunc(){
    clearTimeout(timeOutObj);
    alert('U have stopped Timeout..!');

}
function display(){
    var message= this.id+" "+this.name+" "+this.design+" "+this.salary;
    alert(message);
}
//creating obj in js without class
var emp1 = new Object;
emp1.id = 101;
emp1.name = "Anand";
emp1.desig = "developer";
emp1.salary=25000;
//storing ref of one func in another func
emp1.displayEmp=display;
emp1.displayEmp();

var emp2 = new Object;
emp2.id = 102;
emp2.name = "Anandi";
emp2.desig = "Soft developer";
emp2.salary=35000;
emp2.displayEmp=display;
emp2.displayEmp();