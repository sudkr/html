// if else - ladder Style
function checkEvenOrOdd(num){
    var result;
    if(num.value==0)
    result="0 is Neither Even Nor Odd ..!";
    else if(num.value %2==0)
    result = num.value+ "is a Even Number ..!";
    else
    result = num.value+ "is a Odd Number ..!";
    alert(result);
}

/* Switch Case Construct */
function displayDays(month,year){
    var days;
    switch(parseInt(month.value))
    {
        case 1:  //fall through
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
        {
            days = 31;
        }
        break;
        case 4:
        case 6:
        case 9:
        case 11:
        {
            days = 30;
        }
        break;
        case 2:
        {
            if(year.value%4==0)
            {
                days=29;
            }
            else{
                days=28;
            }
        }
        break;
        default:{
            days=-1;
        }

    }
    if(days==-1)
    alert("Error:Invalid month ..!")
    else 
    alert(month.value+"has"+days+"days");
}

//Ternary operator

function checkTernary(number1,number2){
   
       var result=parseInt(number1.value)==parseInt(number2.value)?
       "Both are equal":(parseInt(number1.value)>parseInt(number2.value)?"greater number is"
       +number1.value:"greater number is"+number2.value);
       alert(result);
    }

   