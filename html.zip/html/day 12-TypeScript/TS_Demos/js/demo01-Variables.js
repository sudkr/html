var eid = 101;
var ename = "Sud";
var salary = 25000.00;
var empStatus = true;
console.log("Employee Id is" + eid);
console.log("Employee Name is" + ename);
console.log("Employee Salary is" + salary);
if (empStatus)
    console.log("Employee is Selected..");
else
    console.log("Employee is Rejected..");
