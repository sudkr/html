//Arrow operator with parameter
var circle = function (r) { return 3.142 * r * r; };
//Arrow Operator without parameter
var areaOfCircle = function () { return console.log(circle(5)); };
areaOfCircle();
//Simple Interest
//Function syntax
//function_keyword function_name([param_list]):[return_type]
function calculateSimpleInterest(pa, noy, roi) {
    var si = pa * noy * roi / 100;
    return si;
}
console.log("SI is " + calculateSimpleInterest(1000, 2, 2));
function calculateArea(a, b) {
    var area;
    if (b === undefined)
        area = 3.142 * a * a;
    else
        area = a * b;
    return area;
}
//Circle
console.log("Area of Circle is" + calculateArea(10));
//Rectangle
console.log("Area of Rectangle is" + calculateArea(10, 20));
//Parameter type Inference
// -> Based on initialied value, type will be decided is known as Type inference
var showType = function (x) {
    if (typeof x == "number") {
        console.log(x + " is numeric");
    }
    else if (typeof x == "string") {
        console.log(x + "is a string");
    }
};
showType(12);
showType("Hello" + " ");
//Rest parameter - variable number of arguments
function addNumbers() {
    var nums = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        nums[_i] = arguments[_i];
    }
    var i;
    var sum = 0;
    for (i = 0; i < nums.length; i++) {
        sum = sum + nums[i];
    }
    // or using For .. in Loop
    // for (i in nums){
    // sum +=i;
    //}
    console.log("sum of the numbers", sum);
}
addNumbers(1, 2, 3);
addNumbers(10, 10, 10, 10, 10);
