var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
//Understanding access specifiers
//[public,private,protected]
var MyClass = /** @class */ (function () {
    function MyClass() {
        //[bydefault] public
        //try to give access specifier private and protected
        this.companyName = "IGATE";
    }
    return MyClass;
}());
//instance of keyword
var myClassObj = new MyClass();
console.log("instanceof Keyword: "
    + (myClassObj instanceof MyClass));
//Incase of private and protected below lines will give an error
//Accessing public member outside the class
console.log("Default Name:" + myClassObj.companyName);
//changing name
myClassObj.companyName = "CapGemini";
//Accesing public member outside the class
console.log("After Name Change:" + myClassObj.companyName);
//Using Constructors to initalize class members
var Product = /** @class */ (function () {
    //constructors and functions must be always public
    //constructors Overloading
    function Product(firstNumber, secondNumber) {
        this.firstNumber = firstNumber;
        this.secondNumber = secondNumber;
    }
    Product.prototype.calculateProduct = function () {
        var result = this.firstNumber * this.secondNumber;
        return result;
    };
    return Product;
}()); //end of Product class
var myProduct1 = new Product(100, 200);
console.log("\n\nProduct of 2 numbers" + myProduct1.calculateProduct());
var myProduct2 = new Product(10, 20);
console.log("\n\nProduct of 2 numbers" + myProduct2.calculateProduct());
//Types of Inheritance
//1-Single level-Only one parent class and one child class
//2-Multi level-Child class is derived from another child class
//3-Multiple-Child classs can be derived from more than one parent class. It is supported directly in Typescript. We have to use interface for that
//4-Hybrid inheritance-Not supported directly combination of hierarchical and multiple inheritance
//5-Hierarchical- Like a family tree
//using inheritance between clasess and method overridng
//use of super keyword and using extends keywod
var Geometry = /** @class */ (function () {
    function Geometry() {
    }
    //Base class Function
    Geometry.prototype.calculate = function () { };
    return Geometry;
}());
var Square = /** @class */ (function (_super) {
    __extends(Square, _super);
    function Square(side) {
        var _this = 
        //invoking base class constructor
        _super.call(this) || this;
        //accesing base class member side
        _this.side = side;
        Square.counter++;
        return _this;
    }
    //overriding calculate() function of geometry class 
    Square.prototype.calculate = function () {
        var area = this.side * this.side;
        console.log("Area of square :" + area);
    };
    Square.getCount = function () {
        return Square.counter;
    };
    Square.counter = 0;
    return Square;
}(Geometry));
var squareObj1 = new Square(5);
squareObj1.calculate();
var squareObj2 = new Square(15);
squareObj2.calculate();
var squareObj3 = new Square(25);
squareObj3.calculate();
console.log("Square Objects count:" + Square.counter);
//using constructors to intialze class members
//using inheritance Betweeen classes
//using inheritance between classes and method overriding
//use of super keywod
