// java style of implementing interfaces
var Bank = /** @class */ (function () {
    function Bank(name, salary, projectName, hoursOfWork) {
        this.name = name;
        this.salary = salary;
        this.projectName = projectName;
        this.hoursOfWork = hoursOfWork;
    }
    //overriding interface funtion
    Bank.prototype.printDetails = function () {
        var details = "Project Name " + this.projectName + "\n             Employee Name " + this.name + "\n             Working Hours " + this.hoursOfWork + "\n             Salary " + this.salary + "\n            ";
        return details;
    };
    return Bank;
}()); //end of class
var empObj = new Employee("Anand", 25000, "Insurance Automation", 100);
console.log(empObj.printDetails());
