//Reusing the functionality of interface
var customerObj = {
    firstName: "Sud",
    lastName: "Baba",
    showFullName: function () {
        return customerObj.firstName + " " + customerObj.lastName;
    }
};
console.log(customerObj.showFullName() + customerObj.firstName + " " + customerObj.lastName);
//var drummer:IMusician;
//or type Assertion
var drummer = {};
drummer.firstName = "Pawan";
drummer.lastName = "Anand";
drummer.age = 25;
drummer.instrument = "Drums";
var details = "\n                 Drummer Name: " + drummer.firstName + drummer.lastName + " \n                 Drummer Age: " + drummer.age + "\n                 Drummer Instrument: " + drummer.instrument + "\n                  ";
console.log(details);
// java style of implementing interfaces
var Employee = /** @class */ (function () {
    function Employee(name, salary, projectName, hoursOfWork) {
        this.name = name;
        this.salary = salary;
        this.projectName = projectName;
        this.hoursOfWork = hoursOfWork;
    }
    //overriding interface funtion
    Employee.prototype.printDetails = function () {
        var details = "Project Name " + this.projectName + "\n             Employee Name " + this.name + "\n             Working Hours " + this.hoursOfWork + "\n             Salary " + this.salary + "\n            ";
        return details;
    };
    return Employee;
}()); //end of class
var empObj = new Employee("Anand", 25000, "Insurance Automation", 100);
console.log(empObj.printDetails());
//Generic functions or function templates in c++
function addition(firstNumber, secondNumber) {
    return (firstNumber + secondNumber);
}
console.log(addition(20, 30));
console.log(addition(30.5, 60.8896));
console.log(addition("Sud", "Baba"));
//Generic class
var Calculator = /** @class */ (function () {
    function Calculator() {
    }
    return Calculator;
}());
var result = new Calculator();
result.add = function (x, y) { return x + y; };
console.log(result.add(50, 60));
//function templets or generic class
var Calculator1 = /** @class */ (function () {
    function Calculator1() {
    }
    Calculator1.prototype.add = function (one, two) {
        return one + two;
    };
    return Calculator1;
}());
var obj1 = new Calculator1();
console.log(obj1.add(10, 20));
var obj2 = new Calculator1();
console.log(obj2.add("10", "20"));
