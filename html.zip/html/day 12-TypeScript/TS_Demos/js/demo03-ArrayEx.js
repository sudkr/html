//Declaring array using Array Indexing Symbol []
var numbers = [10, 20, 30, 40, 50];
console.log("Display Numbers ..!");
for (var n in numbers) {
    console.log(n);
}
//Declaring array using Array() constructor
var newNumbers = new Array(5);
console.log("Display Numbers ..!");
for (var i = 0; i < newNumbers.length; i++) {
    newNumbers[i] = numbers[i] + 10;
}
console.log.apply(console, newNumbers);
//Array Constructor accepts comma separated values]
var studentsList = new Array("Sandesh", "Jeevesh", "Ankit", "Sud");
console.log.apply(console, studentsList);
//Array Destructing
var arrObj = [10, 10];
var x = arrObj[0], y = arrObj[1];
console.log(x);
console.log(y);
//shift()- Removes the first element from an array and returns that element.
//unshift()-Adds one or more elemnts to the front of an array and returns the new length of the array
//splice()-Adds and/or removes elements from an array
//slice()-Extracts a section of an array and returns a new array.
//pop- Removes the last element from an array and returns taht element.
//push()-Adds one or more elements to the end of an array and returns the new length of the array
//2d Array
var twoDArray = [[1, 2, 3], [21, 22, 23]];
console.log.apply(console, twoDArray);
//console.log(twoDArray[0][0])
//console.log(twoDArray[0][1])
//console.log(twoDArray[0][2])
//console.log(twoDArray[0][0])
//console.log(twoDArray[0][1])
//console.log(twoDArray[0][2])
