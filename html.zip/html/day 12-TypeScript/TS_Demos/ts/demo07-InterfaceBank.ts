interface IAccount{
    hoursOfWork: number 
}
interface ICustomer{
    projectName : string
}
// java style of implementing interfaces
class Bank implements IHDFCBank, ICitiBank{
    name:string;
    //overriding members of IHDFCBank and ICitiBank
    projectName: string;
    hoursOfWork: number;
    salary: number;
    constructor(name:string,salary:number,projectName:string,hoursOfWork:number){
        this.name = name;
        this.salary = salary;
        this.projectName = projectName;
        this.hoursOfWork = hoursOfWork;
    }
    //overriding interface funtion
    printDetails():string{
        let details = 
            `Project Name ${this.projectName}
             Employee Name ${this.name}
             Working Hours ${this.hoursOfWork}
             Salary ${this.salary}
            `;
            return details;
    }
}    //end of class

var empObj = new Employee
    ("Anand", 25000, "Insurance Automation",100);
    console.log(empObj.printDetails());
