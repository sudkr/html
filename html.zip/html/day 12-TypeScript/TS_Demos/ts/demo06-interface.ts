interface IPerson {
    firstName: string;
    lastName: string;
    showFullName: () => string
}

//Reusing the functionality of interface
var customerObj: IPerson = {
    firstName: "Sud",
    lastName: "Baba",
    showFullName: (): string => {
        return customerObj.firstName + " " + customerObj.lastName
    }
}
console.log(customerObj.showFullName() + customerObj.firstName + " " + customerObj.lastName);

//Reusing the functionality of interface
//var studentObj: IPerson = {
// firstName: "Kartik",
// lastName:"Suresh",
//showFullName:(): string => this.firstName +" "+this.lastName
//}
//console.log(studentObj.showFullName()+ studentObj.firstName+" "+ studentObj.lastName);
//Interface to Interface inheritance
interface IMusician extends IPerson {
    age: number,
    instrument: string
}
//var drummer:IMusician;
//or type Assertion
var drummer = <IMusician>{};
drummer.firstName = "Pawan";
drummer.lastName = "Anand";
drummer.age = 25;
drummer.instrument = "Drums";

var details = `
                 Drummer Name: ${drummer.firstName}${drummer.lastName} 
                 Drummer Age: ${drummer.age}
                 Drummer Instrument: ${drummer.instrument}
                  `
console.log(details);


//Multiple Interface Inheritance
interface IHDFCBank{
    hoursOfWork: number 
}
interface ICitiBank{
    projectName : string
}
// java style of implementing interfaces
class Employee implements IHDFCBank, ICitiBank{
    name:string;
    //overriding members of IHDFCBank and ICitiBank
    projectName: string;
    hoursOfWork: number;
    salary: number;
    constructor(name:string,salary:number,projectName:string,hoursOfWork:number){
        this.name = name;
        this.salary = salary;
        this.projectName = projectName;
        this.hoursOfWork = hoursOfWork;
    }
    //overriding interface funtion
    printDetails():string{
        let details = 
            `Project Name ${this.projectName}
             Employee Name ${this.name}
             Working Hours ${this.hoursOfWork}
             Salary ${this.salary}
            `;
            return details;
    }
}    //end of class

var empObj = new Employee
    ("Anand", 25000, "Insurance Automation",100);
    console.log(empObj.printDetails());



    //Generic functions or function templates in c++
    function addition<T>(firstNumber: T, secondNumber: T): T{
        return (<any>firstNumber+<any>secondNumber);
    }
    console.log(addition (20,30));
    console.log(addition(30.5,60.8896));
    console.log(addition("Sud","Baba"));

    //Generic class
    class Calculator<T>{
        add: (one:T, two: T)=>T;
    }
    var result = new Calculator<number>();
    result.add = function(x,y) { return x+y; }

    console.log(result.add(50,60));

    //function templets or generic class
    class Calculator1<T>
    {
        add(one:T, two: T){
            return <any>one + <any>two;
        }
    }
    var obj1 = new Calculator1<number>();
    console.log(obj1.add(10,20));
    var obj2 = new Calculator1<string>();
    console.log(obj2.add("10","20"));