//why abstract class -?
// abstract class acts as root of all the classes
// once you mark any class as abstract, it means the class is top most class in hierarchy, hence it is not recommende
//to create object of that class. Instead you create object of
//child classes

//by default every class is called as concrete class
//it is the one which can be instantiated and derived

//abstract class does not allow instantiation
//abstract class consists of abstract functions without body
// non abstract functions with body

abstract class Person{
    //concrete or non abstract function which can body or definition
    //show(): void{

    //}
    //abstract function which has only declaration
    abstract show(): void;
}
//child class must override all abstract function
// of parent class
class Customer extends Person{


show(): void{
    console.log("This is overridden method of person class");
}
}
//let personObj  = new Person();
//Dynamic Polymorphism
let customerObj: Person = new Customer();
customerObj.show();