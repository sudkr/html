//Globally declared variable
var global_Num : number = 100;

class VariableScope{

    //by default class members-meaning variable and functions are public in Typescript
    //instance variable which requires object to access
    //life time of this variable is depends on objects
    //it is bound to object
    
    
    instance_Num: number = 10;
    
    //Note: Static members and non static members of class are bydefault initialized to undefined unline in java, where they are initialized to their default values like 0 for int, etc

    //class variable or static variable which requires classname
    //life time of this variable is depends on class
    //it is bound to class
    static static_Num:number = 1000;

    //non static function
    //non static  function can access non static members and static members
    displayNum(local_Num : number = 5){
        console.log("global_Num :"+global_Num);
        console.log("instance_Num :"+this.instance_Num);
        console.log("local_Num:"+local_Num);
        console.log("static_Num:"+VariableScope.static_Num);
    }

    //static function
    //static function can access only static members
    //non static members are not allowed
    //But you can declare non static member inside
    static displayStaticNumber(): void {
        console.log(VariableScope.static_Num);
        //console.log("instance_Num:"+this.instance_Num);
        //non static member declaration
        //let number=20;
    }
}

var obj = new VariableScope();
console.log("\n\tglobal_Num:"+global_Num);

console.log("VariableScope.static_Num:"+ VariableScope.static_Num);

//Caling with default parameter
obj.displayNum();
//calling with parameter
obj.displayNum();