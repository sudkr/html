//Base type of built -in data types and Custom types
//Dynamic type
var someType: any = 10;
// Class Name for number type is Number
console.log("someType here : typeOf: "+typeof(someType));

someType = "Hello World";
// class name for string type is string
console.log("someType here : typeOf:"+typeof(someType));

//Class name for string type is string
console.log("someType here : typeOf:"+typeof(someType));

someType = null;
console.log("someType here : typeOf:"+typeof(someType));

someType=null;
console.log("someType here : typeOf:"+typeof(someType));

someType=undefined;
console.log("someType here : typeOf:"+typeof(someType));

//Decalring variables
//Static Types - Once you declare any variable with some type
//throught the scope, it cannot take any other type

//Declaring variables
var eid:number = 101;
var ename:string = "Sud";
var salary:number = 25000.00;
var empStatus:boolean = true;

// Dispalying variables
console.log("Employee Id is"+ eid);
console.log("Employee Name is"+ ename);
console.log("Employee Salary is"+ salary);
if(empStatus)
    console.log("Employee is Selected..");
else
    console.log("Employee is Rejected..");

    //
    enum days{
        SUNDAY =1 ,MONDAY,TUESDAY,WEDNESDAY,THRUSDAY,FRIDAY,SATURDAY
    }