//Base type of built -in data types and Custom types
//Dynamic type
var someType = 10;
// Class Name for number type is Number
console.log("someType here : typeOf: " + typeof (someType));
someType = "Hello World";
// class name for string type is string
console.log("someType here : typeOf:" + typeof (someType));
//Class name for string type is string
console.log("someType here : typeOf:" + typeof (someType));
someType = null;
console.log("someType here : typeOf:" + typeof (someType));
someType = null;
console.log("someType here : typeOf:" + typeof (someType));
someType = undefined;
console.log("someType here : typeOf:" + typeof (someType));
//Decalring variables
//Static Types - Once you declare any variable with some type
//throught the scope, it cannot take any other type
//Declaring variables
var eid = 101;
var ename = "Sud";
var salary = 25000.00;
var empStatus = true;
// Dispalying variables
console.log("Employee Id is" + eid);
console.log("Employee Name is" + ename);
console.log("Employee Salary is" + salary);
if (empStatus)
    console.log("Employee is Selected..");
else
    console.log("Employee is Rejected..");
//
var days;
(function (days) {
    days[days["SUNDAY"] = 1] = "SUNDAY";
    days[days["MONDAY"] = 2] = "MONDAY";
    days[days["TUESDAY"] = 3] = "TUESDAY";
    days[days["WEDNESDAY"] = 4] = "WEDNESDAY";
    days[days["THRUSDAY"] = 5] = "THRUSDAY";
    days[days["FRIDAY"] = 6] = "FRIDAY";
    days[days["SATURDAY"] = 7] = "SATURDAY";
})(days || (days = {}));
