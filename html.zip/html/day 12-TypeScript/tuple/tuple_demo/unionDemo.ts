//Union
//Two or more data types are combined using the pipe symbol(|)
//to denote a Union Type. In other words, a union type is written as sequence of types seprated by vertical bars.
 //e.g:
 var val: string | number
 val = 25
 console.log("numeric value of val"+ val)
 val = "Hello World"
 console.log("string value of val"+val)

 //Union Type and function parameter
 function disp(name: string | string[]){
     if(typeof name == "string"){
         console.log(name)
     } else {
         var i;
         for(i = 0; i<name.length;i++){
             console.log(name[i])
         }
     }
 }

 //Union type and array
 var arrType: number[] | string[];
 var i: number;
 arrType = [10,20,30,40]
 console.log("Numeric Array")

 for(i = 0; i< arrType.length;i++){
     console.log(arrType[i])
 }

 arrType = ["Mumbai","Pune","Delhi"]
 console.log("String Array")

 for(i = 0;i< arrType.length;i++){
     console.log(arrType[i])
 }