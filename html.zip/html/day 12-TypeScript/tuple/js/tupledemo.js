//Tuples
//At times, there might be a need to store a collection of values of varied types, Arrays will not serve this purpose.
//e.g:
var studentTupleObj = [101, "Neha"]; //create a tuple
console.log(studentTupleObj[0]);
console.log(studentTupleObj[1]);
var customerTuple = [101, "Shray", "Pune", "Laptop"];
//returns the tuple size
console.log("Items before push" + customerTuple.length);
//append value to the tuple
customerTuple.push(5000);
console.log("customerTuple after push" + customerTuple.length);
console.log("customerTuple before pop" + customerTuple.length);
//removes and returns the last item
console.log(customerTuple.pop() + " popped from the tuple");
console.log("customerTuple after pop" + customerTuple.length);
//Destructing a Tuple
var empObj = [101, "Sud"];
var id = empObj[0], ename = empObj[1];
console.log(id);
console.log(ename);
