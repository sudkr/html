// namespace Geometrical{
export namespace Shapes {
    export class Triangle{
        show(): string{
            return "Triangle";
        }
    }
    export class Square {
        show(): string{
            return "Square";
        }
    }
}
// }
//old way of importing namesoaces in javascript

/// <reference path=""/>