"use strict";
exports.__esModule = true;
// namespace Geometrical{
var Shapes;
(function (Shapes) {
    var Triangle = /** @class */ (function () {
        function Triangle() {
        }
        Triangle.prototype.show = function () {
            return "Triangle";
        };
        return Triangle;
    }());
    Shapes.Triangle = Triangle;
    var Square = /** @class */ (function () {
        function Square() {
        }
        Square.prototype.show = function () {
            return "Square";
        };
        return Square;
    }());
    Shapes.Square = Square;
})(Shapes = exports.Shapes || (exports.Shapes = {}));
// }
//old way of importing namesoaces in javascript
/// <reference path=""/>
