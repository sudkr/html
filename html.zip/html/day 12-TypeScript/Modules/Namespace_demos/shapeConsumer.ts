// import * as shapes from "./shapes";
// let triangleObj = new shapes.Shapes.Triangle(); //shapes.Shapes?
//console.log(triangleObj.show());
//or
import { Shapes } from "./shapes";
let triangleObj = new Shapes.Triangle();
console.log(triangleObj.show());