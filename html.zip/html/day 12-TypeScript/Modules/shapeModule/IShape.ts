export interface IShape{
    draw();
    // to calculate area of shapes
    area(base: number, height?: number): number;
}