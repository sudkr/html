"use strict";
// drawAllShapes(new triangle.Triangle());
exports.__esModule = true;
var Circle_1 = require("./shapeModule/Circle");
var Triangle_1 = require("./shapeModule/Triangle");
function drawAllShapes(shapeToDraw) {
    shapeToDraw.draw();
}
drawAllShapes(new Circle_1.Circle());
drawAllShapes(new Triangle_1.Triangle());
