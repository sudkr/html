// drawAllShapes(new triangle.Triangle());

//or

import {IShape} from "./shapeModule/IShape";
import {Circle} from "./shapeModule/Circle";
import {Triangle} from "./shapeModule/Triangle";

function drawAllShapes(shapeToDraw: IShape){
    shapeToDraw.draw();
}

drawAllShapes(new Circle());
//drawAllShapes(new Triangle());