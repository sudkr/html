export class Product{
    productId: number;
    productName: string;
}
export const company: string = "Capgemini";