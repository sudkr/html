function setEmpDetails(eid,name,desig,salary){
    this.eid = eid;
    this.name = name;
    this.desig = desig;
    this.salary = salary;

    displayEmpDetails = function(deptName){
        var details =  `
                        Emp Id : ${this.eid} \n
                        Emp Name: ${this.name} \n
                        Dept Name : ${deptName} \n
                        Designation :${this.desig} \n
                        Salary : ${this.salary}
        `;
       // alert(details);
     var empObj = window.open("","Emp Details","width=400px,height=500px");
       var empDetails =
        `<html>
       <head>
       <title>Emp Details</title>
      
       <body style='font-family=""Segeo Ui'>
       </head>
       <table>
                  
                    <tr>
                       
                            <th>Name</th>
                            <td>${this.name}</td>
                    </tr>
                    <tr>
                        
                    <th>Department Name</th>
                    <td>${deptName}</td>
            </tr>
            
                    <tr>
                       
                            <th>Designation</th>
                            <td>${this.desig}</td>
                    </tr>
                    <tr>
                       
                            <th>Salary</th>
                            <td>${this.salary}</td>
                    </tr>
                </table>
                </body>
                </html>   `;
                empObj.document.write(empDetails);

    }
}