function billCal(billingFrm){
    alert('1');
    if(billingFrm.checkValidity()){
        
        //console.log('2');
        var title=billingFrm.ddlTitle.value;
        var name=billingFrm.txtName.value;
        var carType=billingFrm.ddlCarType.value;
        var serviceType=billingFrm.chkService.value;
        var costOftheVehicle
            = parseFloat(billingFrm.textCost.value);


            var serviceCharge;
            if(serviceType=="Free Service")
            serviceCharge=200;
            else if(serviceType=="Body Repair")
            {
                if(carType=="Hatch Back")
                serviceCharge=0.15*costOftheVehicle;
                else if(carType=="Small car")
                serviceCharge=0.10*costOftheVehicle;
                else serviceCharge=0.18*costOftheVehicle;
            }
            var message="Thanks for visit "+title+"."+name+".cost of service is "+serviceCharge;
            alert(message);
    }
}
