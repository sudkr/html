/*here showDate Global variable and Date is built in core objects in JS */
var showDate = new Date();
/* this function will be invoked on [onload] event */
    function showDateTime(){
    document.getElementById("showDate").innerHTML="Today's date and time is<b><i> "+showDate+"</i></b>";
}