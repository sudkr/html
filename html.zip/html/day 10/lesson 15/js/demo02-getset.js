// create class rectangle
class Rectangle{
    //construtor with intialize some parametrized value
    constructor(length,breadth){
        this._length_= length;
        this._breadth_ = breadth;
    }
    // setting length
    set length(length){
        this._length_ = length;
    }   
    // getting length
    get length(){
        return this._length_;
    }
    //setting breadth
        set breadth(breadth){
            this._breadth_ = breadth;
        }
        // getting breadth
        get breadth(){
            return this._breadth_;
        }
        calculateArea(){
            let area = this._length_* this._breadth_;
            return area;
        }
    
}

let length = parseFloat(prompt("Enter Length :"));
let breadth = parseFloat(prompt("Enter Breadth :"));

// creating the Rectangle class object
//1st way using properties
let rectObj1 =  new Rectangle();
//intializing with properties i.e get and set methods
rectObj1.length = length;
rectObj1.breadth= breadth;

let area1 = rectObj1.calculateArea();

console.log("Using properties - Area of Rectangle is"+area1);

//2nd way using constructor for initialization
//creating the rectangle class object
let rectObj2 = new Rectangle(length,breadth);
let area2 = rectObj2.calculateArea();

console.log("Area of Constructor - Area of Rectangle is"+area2);