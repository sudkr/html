//Base class
class Product{
    constructor(productId,productName,productPrice,productDescription){
        this._productId_=productId;
        this._productName_=productName;
        this._productPrice_=productPrice;
        this._productDescription_=productDescription;
    }
    //function
    printAllProduct(){
        var productDetails = `Product Id: ${this._productId_}
        Product Name: ${this._productName_}
        Product Price: ${this._productPrice_}
        Product Description: ${this._productDescription_}
        `;
        return productDetails;
    }
} //end of product class
class Product1 extends Product{
    constructor(productId,productName,
                productPrice, productDescription,productType){
                    super(productId,productName,productPrice, productDescription);
                    this._productType_=productType;
                }
                //function
                printAllProduct(){
                    let allDetails = super.printAllProduct()+
                    "Product Type:"+this._productType_;
                    return allDetails;
                }
}//end of Product1 class
class Product2 extends Product{
    constructor(productId,productName,
                productPrice, productDescription,productCategory){
                    super(productId,productName, productPrice, productDescription);
                    this._productCategory_=productCategory;
                }
                //function
                printAllProduct(){
                    let allDetails = super.printAllProduct()+
                    "Product Category:"+this._productCategory_;
                    return allDetails;
                }
}//end of Product2 class

var product1Obj = new Product1("P1","Laptop",
            5000,"My Personal Laptop","Education");
            
var product2Obj = new Product2("P2","refrigerator",
            2000,"Refrigerator for making things cool","Home Appliance");
            
 var product3Obj = new Product2("P3","Washing machine",
            5000,"For cleaning","Home Appliiance");
            
var product4Obj = new Product1("P4","IPhone",
            2000,"Multipurpose Iphone","Education");
           



let allProducts = [];
//CRUD operations
//adding two array -> create
allProducts.push(product1Obj);
allProducts.push(product2Obj);
allProducts.push(product3Obj);
allProducts.push(product4Obj);

//reading from an array -> read
for(var product in allProducts){
    console.log(allProducts[product].printAllProduct());
}
console.log("After sorting in ascending order");
  allProducts.sort((a,b) => a._productPrice_ - b._productPrice_);

  for(var product in allProducts){
      console.log(allProducts[product].printAllProduct)
  }


//updating from an array -> Update
//    let productId = prompt("Enter Product Id");
//     for(var product in allProducts){
//      if(allProducts[product]._productId_ == productId){
//          allProducts[product]._productName_="HP Laptop";
//      }
//      else{
//          console.log("Product Id does not exist");
//     }
//  }
//  console.log("After changing product name :");

//reading from an array -> READ
//   for(var product in allProducts){
//       console.log(allProducts[product].printAllProduct());
//   }

  


//  //Removing from an Array ->DELETE
//  let productId = prompt("Enter Product Id");
//  for(var product in allProducts){
//      if(allProducts[product]._productId_==productId){
//          allProducts.splice(product,1);
//      }
//  }
// console.log("After Removing Product :");
// //Reading from an array -> READ
// for(var product in allProducts){
//     console.log(allProducts[product].printAllProduct());
// }