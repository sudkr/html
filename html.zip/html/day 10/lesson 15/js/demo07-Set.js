//Base class
class Product{
    constructor(productId,productName,productPrice,productDescription){
        this._productId_=productId;
        this._productName_=productName;
        this._productPrice_=productPrice;
        this._productDescription_=productDescription;
    }
    //function
    printAllProduct(){
        var productDetails = `Product Id: ${this._productId_}
        Product Name: ${this._productName_}
        Product Price: ${this._productPrice_}
        Product Description: ${this._productDescription_}
        `;
        return productDetails;
    }
} //end of product class
class Product1 extends Product{
    constructor(productId,productName,
                productPrice, productDescription,productType){
                    super(productId,productName,productPrice, productDescription);
                    this._productType_=productType;
                }
                //function
                printAllProduct(){
                    let allDetails = super.printAllProduct()+
                    "Product Type:"+this._productType_;
                    return allDetails;
                }
}//end of Product1 class
class Product2 extends Product{
    constructor(productId,productName,
                productPrice, productDescription,productCategory){
                    super(productId,productName, productPrice, productDescription);
                    this._productCategory_=productCategory;
                }
                //function
                printAllProduct(){
                    let allDetails = super.printAllProduct()+
                    "Product Category:"+this._productCategory_;
                    return allDetails;
                }
}//end of Product2 class

var product1Obj = new Product1("P1","Laptop",
            5000,"My Personal Laptop","Education");
           
var product2Obj = new Product2("P2","refrigerator",
            2000,"Refrigerator for making things cool","Home Appliance");
            

 var product3Obj = new Product2("P3","Washing machine",
            10000,"For cleaning","Home Appliiance");
            
var product4Obj = new Product1("P4","IPhone",
            8000,"Multipurpose Iphone","Education");
            



//creating Set object using set() constructor
let allProducts = new Set();
//CRUD operations
//adding two Set -> create
    allProducts.add(product1Obj);
    allProducts.add(product2Obj);
    allProducts.add(product3Obj);
    allProducts.add(product4Obj);



 //reading from an array -> read
 for(var product of allProducts){
         console.log(product.printAllProduct());

         }
 //console.log(product2Obj.printAllProduct());

         console.log("After sorting in ascending order");
         let sortedSet = Array.from(allProducts)
         .sort((a,b)=> a._productPrice_ - b._productPrice_);
     for(var product of sortedSet){
         console.log(product.printAllProduct());
   }


//   //updating from an set -> Update
//   let productId = prompt("Enter Product Id");


//   //1st way - using find() method
//   let updateProduct
//     = Array.from(allProducts).find(p => p._productId_ == productId);
//     updateProduct._productName_ = "HP Laptop";

  //2nd way - using for loop and if construct
//   for(var product of allProducts){
//       if(product._productId_ == productId){
//           product._productName_ = "HP Laptop";
//       }
//   }
//   console.log("After Changing Product Name:");
//   //Reading From an set -> Read
//   for(var product of allProducts){
//       console.log(product.printAllProduct());
//   }



//Removing From a set -> Delete
let productId = prompt("Enter Product Id");
  let deleteProduct
    = Array.from(allProducts).find(p => p._productId_ == productId);
allProducts.delete(deleteProduct);
console.log("After Removing Product :");
//Reading From an set ->Read
for(var product of allProducts){
    console.log(product.printAllProduct());
}


//updating from an array -> Update
//    let productId = prompt("Enter Product Id");
//     for(var product in allProducts){
//      if(allProducts[product]._productId_ == productId){
//          allProducts[product]._productName_="HP Laptop";
//      }
//      else{
//          console.log("Product Id does not exist");
//     }
//  }
//  console.log("After changing product name :");

//reading from an array -> READ
//   for(var product in allProducts){
//       console.log(allProducts[product].printAllProduct());
//   }
