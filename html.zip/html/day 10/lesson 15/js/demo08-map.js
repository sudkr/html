//Base class
class Product{
    constructor(productId,productName,productPrice,productDescription){
        this._productId_=productId;
        this._productName_=productName;
        this._productPrice_=productPrice;
        this._productDescription_=productDescription;
    }
    //function
    printAllProduct(){
        var productDetails = `Product Id: ${this._productId_}
        Product Name: ${this._productName_}
        Product Price: ${this._productPrice_}
        Product Description: ${this._productDescription_}
        `;
        return productDetails;
    }
} //end of product class

class Product1 extends Product{
    constructor(productId,productName,
                productPrice, productDescription,productType){
                    super(productId,productName,productPrice, productDescription);
                    this._productType_=productType;
                }
                //function
                printAllProduct(){
                    let allDetails = super.printAllProduct()+
                    "Product Type:"+this._productType_;
                    return allDetails;
                }
}//end of Product1 class
class Product2 extends Product{
    constructor(productId,productName,
                productPrice, productDescription,productCategory){
                    super(productId,productName, productPrice, productDescription);
                    this._productCategory_ =productCategory;
                }
                //function
                printAllProduct(){
                    let allDetails = super.printAllProduct()+
                    "Product Category:"+this._productCategory_;
                    return allDetails;
                }
}//end of Product2 class

var product1Obj = new Product1("P1","Laptop",
            5000,"My Personal Laptop","Education");
           
var product2Obj = new Product2("P2","refrigerator",
            2000,"Refrigerator for making things cool","Home Appliance");
            

 var product3Obj = new Product2("P3","Washing machine",
            10000,"For cleaning","Home Appliiance");
            
var product4Obj = new Product1("P4","IPhone",
            8000,"Multipurpose Iphone","Education");
            



//creating Set object using set() constructor
let allProducts = new Map();
//CRUD operations
//adding two Map -> create
    allProducts.set(1,product1Obj);
    allProducts.set(2,product2Obj);
    allProducts.set(3,product3Obj);
    allProducts.set(4,product4Obj);



 //reading from an array -> read
  for(var [k,v] of allProducts){
          console.log(allProducts.get(k).printAllProduct());

         }
 

          console.log("After sorting in ascending order");
        //  //1st way
        //    let sortedMap = new Map([...allProducts.entries()]
        //  .sort((a,b)=> a[1]._productPrice_ - b[1]._productPrice_));

        //2nd way
          let sortedMap = Array.from(allProducts)
          .sort((a,b) => a[1]._productPrice_ - b[1]._productPrice_);
       for(var [k,v] of sortedMap){
            console.log(allProducts.get(k).printAllProduct());
      }


    //find
    let productId = prompt("Enter Product Id");
    //1st way - using find() method
    //update
    let updateProduct
        = Array.from(allProducts).find
            (p => p[1]._productId_ === productId);
             updateProduct[1]._productName_ = "HP LAPTOP";
 console.log("After Changing Product name :");
 for(var [k,v] of allProducts){
     console.log(allProducts.get(k).printAllProduct()) ;
    
 }


//Removing From an Map->delete
let productId1 = prompt("Enter Product Id");
let deletedProduct
    =Array.from(allProducts).find
    (p => p[1]._productId_ === productId);
    allProducts.delete(deletedProduct[0]);
    console.log("After Removing Product :");
for(var [k,v] of allProducts){
    console.log(allProducts.get(k).printAllProduct());
    
}












  


