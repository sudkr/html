// create class rectangle
class Rectangle{
    constructor(){
        console.log("Constructor of Rectangle class is called ...!");
    }
    calculateArea(r){
        let area =  3.142*r*r;
        return area;
    }
}
let rectObj =  new Rectangle();
let radius = parseFloat(prompt("Enter Radius :"));
let area =  rectObj.calculateArea(radius);
console.log(area);

class square{
    constructor(){
        console.log("Constructor of circle class is called ...!")
    }
    calculateArea(l,b){
        let area = l*b;
        return area;
    }
}
let sqrObj =  new square();
let length = parseFloat(prompt("Enter Length :"));
let breadth = parseFloat(prompt("Enter Breadth :"));
let area1 =  rectObj.calculateArea(length);

console.log(area);