//base class
class Shape{
    constructor(radius, length, breadth){
        this._radius_ = radius;
        this._length_ = length;
        this._breadth_ = breadth;
    }
    claculateArea(){
        console.log("This is Shape class ...!");
    }
}
//Derived class
class Circle extends Shape{
    constructor(radius){
        super(radius);
            //this._radius_ = radius;
        }
    
claculateArea(){
    let area = 3.142 * this._radius_*this._radius_;
    return area;
}
}
//Derived class
class Rectangle extends Shape{
    constructor(length, breadth){
        super();
        this._length_ = length;
        this._breadth_ = breadth;
    }
    claculateArea(){
        let area = this._length_* this._breadth_;
        return area;
    }
}
// circle class object
let circleObj = new Circle(radius = 5);
console.log("Area of circle is:"+ circleObj.claculateArea());

// rectangle class object
let rectObj = new Rectangle(length=5,breadth=6);
console.log("Area of rectangle is:"+rectObj.claculateArea());