function isAuthorized(frmLogin){
    if(frmLogin.checkValidity()){
        var txtUser = frmLogin.txtUser.value;
        var txtPass = frmLogin.txtPass.value;

        var storedUser = localStorage.getItem("txtUser");
        var txtPass = localStorage.getItem("txtPass");

        if(txtUser == storedUser && txtPass == storedPass){
            window.open("loginSuccess.html");
        } 
        else{
            alert('Wrong Username/Password');
        }
    }
}
function isAccessAllowed(){
    var txtUser=localStorage.getItem("txtUser");

    if(txtUser==null){
        window.location.href="Login.html";
    }
    document.getElementById("txtUser").innerHTML=txtUser;
}