function validateCustID(txtCUSTID){
    var custID = parseInt(txtCUSTID.value);
    var flag = true;
    if(isNaN(custID) || (custID > 110 || custID < 101)){
        flag = false;
        document.getElementById("showError").innerHTML = '*Valid CustomerID Between 101-110';

    }
    else
    {
        document.getElementById("showError").innerHTML ='&nbsp;';
    }
    return flag;
}
function validateAccNumber(txtAccNumber){
    var AccNumber = parseInt(txtAccNumber.value);
    var flag = true;
    if(isNaN(AccNumber) || (AccNumber > 10010 || AccNumber < 10001)){
        flag = false;
        document.getElementById("showError").innerHTML = '*Valid AccNumber Between 10001-10010';

    }
    else
    {
        document.getElementById("showError").innerHTML ='&nbsp;';
    }
    return flag;
} 
function validateOpeningAmt(txtOpeningAmt){
    var OpeningAmt = parseInt(txtOpeningAmt.value);
    var flag = true;
    if(isNaN(OpeningAmt) || (OpeningAmt < 50000)){
        flag = false;
        document.getElementById("showError").innerHTML = '*Minimum opening Balance Must be 5000 Rs';

    }
    else
    {
        document.getElementById("showError").innerHTML ='&nbsp;';
    }
    return flag;
} 
function afterSubmit(registerForm){
    if(registerForm.checkValidity()){
        if(validateCustID(registerForm.txtCUSTID)&& validateAccNumber(registerForm.txtAccNumber)&& validateOpeningAmt(registerForm.txtOpeningAmt)){
            alert('Account Creation Successful !!');

            var txtCUSTID = registerForm.txtCUSTID.value;
            var txtName = registerForm.txtName.value;
            var ddlCity = registerForm.ddlCity.value;
            var numAge = registerForm.numAge.value;
            var txtUser = registerForm.txtUser.value;
            var rbtnAccType = registerForm.rbtnAccType.value;
            var txtAccNumber = registerForm.txtAccNumber.value;
            var txtOpeningAmt = registerForm.txtOpeningAmt.value;
            var sessionID = 'On';

            localStorage.setItem("txtCUSTID", txtCUSTID);
            localStorage.setItem("txtName", txtName);
            localStorage.setItem("ddlCity", ddlCity);
            localStorage.setItem("numAge", numAge);
            localStorage.setItem("txtUser", txtUser);
            localStorage.setItem("txtPass", txtPass);
            localStorage.setItem("rbtnAccType", rbtnAccType);
            localStorage.setItem("txtAccNumber", txtAccNumber);
            localStorage.setItem("txtOpeningAmt", txtOpeningAmt);
            localStorage.setItem("sessionID", sessionID);

        }
    }
} 
