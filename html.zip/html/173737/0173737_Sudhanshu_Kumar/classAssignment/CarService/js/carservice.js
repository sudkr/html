function calculateBill(frmBillingObj){
    if(frmBillingObj.checkValidity()){

        var title=frmBillingObj.ddlTitle.value;
        var name=frmBillingObj.txtName.value;
        var carType=frmBillingObj.ddlCarType.value;
        var serviceType=frmBillingObj.rbtnService.value;
        var costofTheVehicle=parseFloat(frmBillingObj.txtCost.value);

        var serviceCharge;
        if(serviceType=="Free Service")
        serviceCharge=200;
        else if(serviceType=="Body Repair")
        {
            if(carType=="hatchback")
            serviceCharge =0.15*costofTheVehicle;
            else if(carType=="smallcars")
            serviceCharge = 0.10*costofTheVehicle;
            else 
            serviceCharge = 0.18*costofTheVehicle;
        }
      var message = "Thanks for Visit " + title+"."+name+". Cost of Service is" + serviceCharge;
      alert(message);
    }
}