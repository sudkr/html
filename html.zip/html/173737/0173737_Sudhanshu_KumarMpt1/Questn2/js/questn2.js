// Base class
class Inventory {
    // constructor
    constructor() {
    }
    // getProductIn() function
    getProductIn() {

    }
    // getProductOut() function
    getProductOut() {

    }
} // end of Inventory class

class Product     {
    // constructor
    constructor(prodId, prodName, prodPrice, prodDescription) {
        //super();
        this._prodId_ = prodId;
        this._prodName_ = prodName;
        this._prodPrice_ = prodPrice;
        this._prodDescription_ = prodDescription;
    }
    // getProductIn() overriden function of Inventory Class
    getUserIn() {
        console.log("Product Logged In ..!");
    }
    // getProductOut() overriden function of Inventory Class
    getUserOut() {
        console.log("Product Logged Out ..!");
    }
    //  showAllProduct() function
    showAllProduct() {
        let productDetails =
            ` Product Id : ${this._prodId_}
          Product Name : ${this._prodName_}
          Product Price : ${this._prodPrice_}
          product Description : ${this._prodDescription_}
        `;
        return productDetails;
    }
} // end of Product class

// ProductUtility class for CRUD Operations
class ProductUtility {
    // addProduct() function
    constructor() {
        this._productList_ = new Map();
        let product1 = new Product(1002, "Mobile", 19812, "Mobile");
        let product2 = new Product(1003, "Rice", 66, "Grocery");
        let product3 = new Product(1001, "Pen", 32, "Stationary");
        let product4 = new Product(1000, "Pencil", 8, "Stationary");

        this._productList_.set(1, product1);
        this._productList_.set(2, product2);
        this._productList_.set(3, product3);
        this._productList_.set(4, product4);
    }

    getAllProductList() {
        return this._productList_;
    }
   
    deleteProduct() {
        let prod2Id = parseInt(prompt("Enter Product Id "));

        let deletedProduct
            = Array.from(this._productList_).find
                (prod2 => prod2[1]._prodId_ === prod2Id);

        let result = false;
        if (deletedProduct !== undefined)
            result = this._productList_.delete(deletedProduct[0]);

        return result;
    }
    showAllProductOrderByPrice() {
        let sortedProductList = Array.from(this._productList_)
            .sort((a, b) => a[1]._prodPrice_ - b[1]._prodPrice_);
        return sortedProductList;
    }
}

// Menu Driven
console.log("Menu: ");
console.log("\t1: Add Product ");
console.log("\t2: Show All Product ");
console.log("\t3: Show All Product Order By Price");
console.log("\t4: Delete Product");
console.log("\t0: Exit");

let utilityObj;
let choiceYN = 'N';

do {
    let choice = parseInt(prompt("Enter Ur Choice"));

    switch (choice) {
        // Add Product
        case 1: {
            utilityObj = new ProductUtility();
            console.log('\n\n\tAll Product are Added ');
        } break;

        // Show All Products
        case 2: {
            var productList = utilityObj.getAllProductList();
            console.log("\n\n\tBelow Given is the List of Products ..!");
            // Reading From an Map -> READ
            for (var [k, v] of productList) {
                console.log(productList.get(k).showAllProduct());
            }
        } break;

        // Show All Product Order By Price
        case 3: {
            console.log("\n\n\tAfter sorting in Ascending order");
            let sortedProductList = utilityObj.showAllProductOrderByPrice();
            for (var [k, v] of sortedProductList) {
                console.log(productList.get(k).showAllProduct());
            }
        }

        // Delete Product
        case 4: {
            console.log("\n\n\tAfter Deleting Product from the List ..!");

            if (utilityObj.deleteProduct()) {
                for (var [k, v] of productList) {
                    console.log(productList.get(k).showAllProduct());
                }
            }
            else {
                console.log("\n\n\tProduct Does Not Exist ..!");
            }
        } break;

        default: {
            console.log("\n\n\tInvalid Choice ..! ");
        }
            break;
        case 0: {
            console.log("\n\n\tThank you ..! ");
            break;
        }
    }

    choiceYN = prompt("Do you wants to continue ?");
} while (choiceYN === 'Y' || choiceYN === 'y');