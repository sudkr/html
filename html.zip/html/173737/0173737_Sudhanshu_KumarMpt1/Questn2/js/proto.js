// Base class
class Inventory {
    // constructor
    constructor() {
    }
    // getProductIn() function
    getProductIn() {
            return "getProductIn() function called ..!";
    }
    // getProductOut() function
    getProductOut() {
        return "getProductOut() function called ..!";

    }
} // end of Inventory class

class Product  {
    // constructor
    constructor(prodId, prodName, prodPrice, prodDescription) {
        
        this._prodId_ = prodId;
        this._prodName_ = prodName;
        this._prodPrice_ = prodPrice;
        this._prodDescription_ = prodDescription;
    }
    // getProductIn() overriden function of Inventory Class
    getInventoryIn() {
        console.log("Product Logged In ..!");
    }
    // getProductOut() overriden function of Inventory Class
    getProductOut() {
        console.log("Product Logged Out ..!");
    }
    //  showAllProduct() function
    showAllProduct() {
        let productDetails =
            ` Product Id : ${this._prodId_}
          Product Name : ${this._prodName_}
          Product Price : ${this._prodPrice_}
          product Description : ${this._prodDescription_}
        `;
        return productDetails;
    }
} // end of Product class

let inventoryObj = new Inventory();
let ProductObj = new User(1005, "Sud", 25, "Pune");

// By using _proto_ 
// ProductObj._proto_ = inventoryObj;
// console.log(ProductObj._proto_.showAllProducts());

// By using Object.create() function
console.log(ProductObj.showAllProducts());
productObj = Object.create(inventoryObj);
console.log(productObj.getProductIn());