function customerDetails(frm){
    if(frm.checkValidity()){
        var customerName=frm.txtName.value;
        var customerAddress=frm.txtAddress.value;
        var customerState=frm.drpdnState.value;
        var phone=frm.numPhone.value;
        var mail=frm.txtEmail.value;
        var wayofContact=frm.rbtnContact.value;
        var dateOfVisit=frm.txtIncident.value;
        var incident=frm.txtIncident.value;
        displayCustDetails();

        function displayCustDetails(){
            var custObj=window.open("","Customer Details","width=300px,height=500px");
            var custDetails=`
                    <html>
                    <head>
                      <title>Dear customer,please confirm your details...!</title>
                      </head>
                    <body>
                    <h2>Dear customer,please confirm your details..!</h2>
                    <table>
                    <tr>
                    <th>Customer Name</th>
                    <td>${customerName}</td>
                    </tr>
                    <tr>
                      <th>Address</th>
                      <td>${customerAddress}</td>
                    </tr>
                    <tr>
                      <th>State</th>
                      <td>${customerState}</td>
                    </tr>
                    <tr>
                      <th>Phone</th>
                      <td>${customerPhone}</td>
                    </tr>
                    <tr>
                      <th>Mail</th>
                      <td>${Mail}</td>
                    </tr>
                    <tr>
                      <th>Way of Contact</th>
                      <td>${wayofContact}</td>
                    </tr>
                    <tr>
                      <th>Date of Visit</th>
                      <td>${dateOfVisit}</td>
                    </tr>
                    <tr>
                      <th>incident</th>
                      <td>${incident}</td>
                    </tr>
                    </table>
                    </body>
                    </html>`;
                    custObj.document.write(custDetails);
                    
                    
        }
    }
}