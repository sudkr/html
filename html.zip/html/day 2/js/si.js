function usernameExit(){
    if(localStorage.getItem("username") 
    ==null)
        {
            window.location="../pages/login.html";
        }
        document.getElementById("welcome").innerHTML = "welcome to" + localStorage.getItem("username");
}
//logoff() function
function logoff(){
    var result = confirm("Do you wants to Logoff ?");
    if(results){
    //localStorage.length-->returns how many keys 
    //stored inside the localStorage object
    localStorage.removeItem("username");
    //clears all keys in one go
    if(localStorage.getItem("username")
    == null)
    window.location="../pages/login.html";
}

}
function calculatesSI(pa, noy, roi){
    if(pa.value== "" || noy.value == ""
        || roi.value==""){
            alert('Please fill all boxes..!');
            return;
        }
    var si=parseFloat(pa.value) *
            parseInt(noy.value)
            parseFloat(roi.value)/100;
            document.getElementById("result")
            .innerHTML="Simple Interest is"+si;
}