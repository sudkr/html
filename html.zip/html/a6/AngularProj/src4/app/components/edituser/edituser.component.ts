import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { UserService } from "src/app/services/user.service";

@Component({
  selector: "app-edituser",
  templateUrl: "./edituser.component.html",
  styleUrls: ["./edituser.component.css"]
})
export class EdituserComponent implements OnInit {
  editform: FormGroup;
  submitted: boolean = false;

  constructor(
    private formbuilder: FormBuilder,
    private router: Router,
    private userservice: UserService
  ) {}

  ngOnInit() {
    if (localStorage.getItem("username") != null) {
      let userId = localStorage.getItem("editUserId");
      if (!userId) {
        alert("Invalid Action");
        this.router.navigate(["list-user"]);
        return;
      }

      this.editform = this.formbuilder.group({
        id: [],
        firstname: ["", Validators.required],
        lastname: ["", Validators.required],
        email: ["", Validators.required]
      });

      this.userservice.getUsersById(+userId).subscribe(data => {
        this.editform.setValue(data);
      });
    } else {
      this.router.navigate(["/login"]);
    }
  }
  onSubmit() {
    this.submitted = true;
    if (this.editform.invalid) {
      return;
    }
    this.userservice.UpdateUser(this.editform.value).subscribe(data => {
       this.router.navigate(["/list-user"]);

      this.userservice.getusers().subscribe();
    });
  }
}
