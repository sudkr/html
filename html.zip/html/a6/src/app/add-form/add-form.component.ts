import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { TaskService } from '../services/task.service';

@Component({
  selector: 'app-add-form',
  templateUrl: './add-form.component.html',
  styleUrls: ['./add-form.component.css']
})
export class AddFormComponent implements OnInit {

  addForm: FormGroup;
  submitted: boolean = false;
  constructor(private formbuilder: FormBuilder,
    private router: Router,
    private taskservice: TaskService) { }

  ngOnInit() {
    this.addForm = this.formbuilder.group({
      id: [],
      name: ['', Validators.required], 
      Status: ['', Validators.required]
    });
  }
  goback(){
    this.router.navigate(['todo-list']);
  }
  onSubmit(){
    this.submitted=true;
    if(this.addForm.invalid){
      return true;
    }
    this.taskservice.createtask(this.addForm.value).subscribe(data=>{alert
      (this.addForm.controls.value +'record added..!')});
      this.router.navigate(['todo-list']);
  }

}
