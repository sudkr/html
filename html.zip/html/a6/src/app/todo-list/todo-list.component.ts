import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Task } from '../model/task';
import { TaskService } from '../services/task.service';

@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.component.html',
  styleUrls: ['./todo-list.component.css']
})
export class TodoListComponent implements OnInit {

  tasks:Task[];
  constructor(private taskservice: TaskService, 
    private router: Router) { }

  ngOnInit() {
    if(localStorage.getItem("username")!= null){
      this.taskservice.getTasks().subscribe(data=>{
        this.tasks =data ;
      });
    }
    else{
      this.router.navigate(['/login']);
    }
  }
  


  deletetask(task: Task):void {
    let result = confirm("do you really want to delete the task?")
    if(result){
      this.taskservice.deletetask(task.id).subscribe(data=>{
        this.tasks =this.tasks.filter(u=> u!== task);
      });
    }    
  }
  addtask():void {
      this.router.navigate(['add']);
  }

  edittask(task: Task):void{
    localStorage.removeItem("editTaskId");
    localStorage.setItem("editTaskId", task.id.toString());
    this.router.navigate(['edit']);
  } 
  
  
}
  
